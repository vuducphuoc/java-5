CREATE PROC sp_thongKeDoanhThuChuyenDe (@year INT)
AS
BEGIN
	SELECT  dbo.ChuyenDe.tenCD [Tên chuyên đề],
			COUNT(dbo.HocVien_KhoaHoc.maKH) [Số khóa học],
			COUNT(dbo.HocVien_KhoaHoc.maHV) [Số học viên],
			SUM(dbo.KhoaHoc.hocPhi)	[Tổng doanh thu],
			MAX(dbo.KhoaHoc.hocPhi) [Học cao nhất],
			MIN(dbo.KhoaHoc.hocPhi)	[Học phí thấp nhất],
			AVG(dbo.KhoaHoc.hocPhi)	[Học phí trung bình]		
	FROM dbo.ChuyenDe
	INNER JOIN dbo.KhoaHoc ON KhoaHoc.maCD = ChuyenDe.maCD
	INNER JOIN dbo.HocVien_KhoaHoc ON HocVien_KhoaHoc.maKH = KhoaHoc.maKH
	WHERE YEAR(dbo.KhoaHoc.ngayKG) = @year
	GROUP BY dbo.ChuyenDe.tenCD
END 
	
	-- Gọi sp_thongKeDoanhThuChuyenDe:
	EXEC dbo.sp_thongKeDoanhThuChuyenDe @year = 2019 -- int

/* Thống kê điểm theo chuyên đề*/
IF OBJECT_ID('sp_thongKeDiemTheoCD') IS NOT NULL
	DROP PROC sp_thongKeDiemTheoCD
go

