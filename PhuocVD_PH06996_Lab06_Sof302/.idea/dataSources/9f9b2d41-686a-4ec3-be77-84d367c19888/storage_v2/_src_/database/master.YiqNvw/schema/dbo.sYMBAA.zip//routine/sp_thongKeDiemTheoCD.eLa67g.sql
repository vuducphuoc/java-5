CREATE PROC sp_thongKeDiemTheoCD
AS
BEGIN
    SELECT dbo.ChuyenDe.tenCD [Tên CĐ],
			COUNT(dbo.HocVien_KhoaHoc.maHV_KH) [Số lượng học viên],
			MAX(dbo.HocVien_KhoaHoc.diem) [Điểm cao nhất],
			MIN(dbo.HocVien_KhoaHoc.diem) [Điểm thấp nhất],
			AVG(dbo.HocVien_KhoaHoc.diem) [Điểm trung bình]
	FROM dbo.ChuyenDe
	INNER JOIN dbo.KhoaHoc ON KhoaHoc.maCD = ChuyenDe.maCD
	INNER JOIN dbo.HocVien_KhoaHoc ON HocVien_KhoaHoc.maKH = KhoaHoc.maKH
	GROUP BY dbo.ChuyenDe.tenCD
END
	-- Gọi sp_thongKeDiemTheoCD
	EXEC dbo.sp_thongKeDiemTheoCD


/* Thống kê bảng điểm*/
IF OBJECT_ID('sp_bangDiem') IS NOT NULL
	DROP PROC sp_bangDiem
go

