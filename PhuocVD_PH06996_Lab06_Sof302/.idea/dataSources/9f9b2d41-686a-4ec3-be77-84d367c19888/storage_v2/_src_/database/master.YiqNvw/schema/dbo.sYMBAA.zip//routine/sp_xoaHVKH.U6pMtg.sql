CREATE PROC sp_xoaHVKH (@maHVKH INT)
AS
BEGIN
    DECLARE @diem FLOAT;
	DECLARE @flagDel INT;
	SET @diem = (SELECT diem FROM dbo.HocVien_KhoaHoc WHERE id = @maHVKH);

	IF @diem IS NULL
		BEGIN
			DELETE dbo.HocVien_KhoaHoc WHERE id = @maHVKH;
			SET @flagDel = 1;
		END
	ELSE
		SET @flagDel = 0;

	SELECT @flagDel;
END

	EXEC dbo.sp_xoaHVKH @maHVKH = 1 -- int


go

