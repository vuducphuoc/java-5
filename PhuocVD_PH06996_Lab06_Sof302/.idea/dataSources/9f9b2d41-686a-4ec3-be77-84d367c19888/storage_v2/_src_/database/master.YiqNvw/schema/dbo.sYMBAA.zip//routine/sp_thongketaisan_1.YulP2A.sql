create proc sp_thongketaisan_1
as begin
	SELECT DISTINCT pl.TENPL, COUNT(ts.MATS) as 'SL', SUM(CAST(NGUYENGIA AS BIGINT)) as 'Tong gia tri'
	FROM dbo.TAISAN ts INNER JOIN dbo.PHANLOAI pl on ts.MAPL = pl.ID
	GROUP BY pl.TENPL
END
go

